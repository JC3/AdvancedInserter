require("prototypes.advanced-inserter")
require("prototypes.advanced-inserter-facade")
require("prototypes.advanced-inserter-lamp")
